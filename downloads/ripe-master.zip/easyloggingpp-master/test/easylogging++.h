// Header for test that sub-includes original header from src/ folder
#ifndef EASYLOGGING_FOR_TEST_H
#define EASYLOGGING_FOR_TEST_H
#include "../src/easylogging++.h"
#endif // EASYLOGGING_FOR_SAMPLES_H
