// Header for sample that sub-includes original header from src/ folder
#ifndef EASYLOGGING_FOR_SAMPLES_H
#define EASYLOGGING_FOR_SAMPLES_H
#include "../../../src/easylogging++.h"
#endif // EASYLOGGING_FOR_SAMPLES_H
